import { isRecord } from "./record";


// Description of an individual poll
export type Poll = {
    readonly name: string,
    readonly options: Option[],
    readonly endTime: number,  
};

//Description of an option
export type Option = {name: string, stat: number, voteNum: number};
  
  
/**
* Parses unknown data into a Poll. Will log an error and return undefined
* if it is not a valid Poll.
* @param val unknown data to parse into a Poll
* @return Poll if val is a valid Poll and undefined otherwise
*/
export const parsePoll = (val: unknown): undefined | Poll => {
    if (!isRecord(val)) {
      console.error("not a poll", val)
      return undefined;
    }
  
    if (typeof val.name !== "string") {
      console.error("not a poll: missing 'name'", val)
      return undefined;
    }
  
    if (typeof val.endTime !== "number" || val.endTime < 0 || isNaN(val.endTime)) {
      console.error("not a poll: missing or invalid 'endTime'", val)
      return undefined;
    }

    const options: Option[] | undefined = parseOptions(val.options);
    if(options === undefined){
        console.error("not a poll: invalid options", val)
        return undefined;
    }
  
    return {
      name: val.name, options: options, endTime: val.endTime
    };
};

/** Parses unknown data into an array of Options 
* @param val unknown data to parse into an array of Options
* @return array of Options if val is a valid and undefined otherwise
*/
export const parseOptions = (val: unknown): undefined | Option[] => {
    if (!Array.isArray(val)) {
        console.error("not an array", val)
        return undefined;
    }

    const options: Option[] = [];
    for (const item of val) {
        if (!isRecord(item)) {
            console.error("option is not a record", item);
            return undefined;
        } else if (typeof item.name !== 'string') {
            console.error("option.name is missing or invalid", item.name);
            return undefined;
        } else if(typeof item.stat !== 'number'){
            console.error("option.stat is missing or invalid", item.stat);
            return undefined;
        } else if(typeof item.voteNum !== 'number'){
            console.error("option.voteNum is missing or invalid", item.voteNum);
            return undefined;
        } else {
            options.push({name: item.name, stat: item.stat, voteNum: item.voteNum});
        }
    }
    return options;
}


