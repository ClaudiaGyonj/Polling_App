import * as assert from 'assert';
import { hasAtLeastTwoLines, stringToOptions } from './NewPoll';


describe('functions', function() {

    const lines1: string = "hi\nyou";
    const lines2: string = "go\nto\nthe\nbeach";
    const lines3: string = "";
    const lines4: string = "hi";
    const lines5: string = "good\ndog";
    const lines6: string = "why\nhello\nthere";
    const lines7: string = "good\nmorning\nfriend";
    const lines8: string = "do\nyour\nbest\nalways";


  it('hasAtLeastTwoLines', function() {
    //First subdomain, first test case
    assert.deepStrictEqual(hasAtLeastTwoLines(lines1), true);
    //First subdomain, second test case
    assert.deepStrictEqual(hasAtLeastTwoLines(lines2), true);
    //Second subdomain, first test case
    assert.deepStrictEqual(hasAtLeastTwoLines(lines3), false);
    //Second subdomain, second test case
    assert.deepStrictEqual(hasAtLeastTwoLines(lines4), false);
  });



  it('stringToOptions', function() {
    //first subdomain, first test case
    assert.throws(() => stringToOptions(lines3), Error);
    //first subdomain, second test case
    assert.throws(() => stringToOptions(lines4), Error);
    //2 loops, first test case
    assert.deepStrictEqual(stringToOptions(lines1), [{name: "hi", stat: 0, voteNum: 0}, {name: "you", stat: 0, voteNum: 0}])
    //2 loops, second test case
    assert.deepStrictEqual(stringToOptions(lines5), [{name: "good", stat: 0, voteNum: 0}, {name: "dog", stat: 0, voteNum: 0}])
    //3 loops, first test case
    assert.deepStrictEqual(stringToOptions(lines6), [{name: "why", stat: 0, voteNum: 0}, {name: "hello", stat: 0, voteNum: 0}, {name: "there", stat: 0, voteNum: 0}]);
    //3 loops, second test case
    assert.deepStrictEqual(stringToOptions(lines7), [{name: "good", stat: 0, voteNum: 0}, {name: "morning", stat: 0, voteNum: 0}, {name: "friend", stat: 0, voteNum: 0}]);
    //4 loops, first test case
    assert.deepStrictEqual(stringToOptions(lines2), [{name: "go", stat: 0, voteNum: 0}, {name: "to", stat: 0, voteNum: 0}, {name: "the", stat: 0, voteNum: 0}, {name: "beach", stat: 0, voteNum: 0}])
    //4 loops, second test case
    assert.deepStrictEqual(stringToOptions(lines8), [{name: "do", stat: 0, voteNum: 0}, {name: "your", stat: 0, voteNum: 0}, {name: "best", stat: 0, voteNum: 0}, {name: "always", stat: 0, voteNum: 0}])

  });

});