import React, { Component, ChangeEvent, MouseEvent } from 'react';
import { isRecord } from './record';
import { Option } from './poll';


type NewPollProps = {
  onBackClick: () => void,
  onCreateClick: (name: string) => void
};

type NewPollState = {
  name: string,
  options: string,
  minutes: string,
  error: string
};


// Allows the user to create a new poll.
export class NewPoll extends Component<NewPollProps, NewPollState> {

  constructor(props: NewPollProps) {
    super(props);
    this.state = {name: "", options: "", minutes: "", error: ""};
  }

  render = (): JSX.Element => {
    return (
        <div>
          <h2>New Poll</h2>
            <div>
                <label htmlFor="name">Name:</label>
                <input id="name" type="text" value={this.state.name}
                    onChange={this.doNameChange}></input>
            </div>
            <div>
                <label htmlFor="num">Minutes:</label>
                <input id="num" type="number" min="1" value={this.state.minutes}
                    onChange={this.doMinutesChange}></input>
            </div>
            <div>
                <label htmlFor="textbox">Options (one per line, minimum two lines):</label>
                <br/>
                <textarea id="textbox" rows={5} cols={40} value={this.state.options}
                    onChange={this.doOptionsChange}></textarea>
            </div>
            <button type="button" onClick={this.doCreateClick}>Create</button>
            <button type="button" onClick={this.doBackClick}>Back</button>
            {this.renderError()}
        </div>
    );
  };

  renderError = (): JSX.Element => {
    if (this.state.error.length === 0) {
      return <div></div>;
    } else {
      const style = {width: '300px', backgroundColor: 'rgb(246,194,192)',
          border: '1px solid rgb(137,66,61)', borderRadius: '5px', padding: '5px' };
      return (<div style={{marginTop: '15px'}}>
          <span style={style}><b>Error</b>: {this.state.error}</span>
        </div>);
    }
  };

  doNameChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({name: evt.target.value, error: ""});
  };

  doOptionsChange = (evt: ChangeEvent<HTMLTextAreaElement>): void => {
    this.setState({options: evt.target.value, error: ""});
  };

  doMinutesChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({minutes: evt.target.value, error: ""});
  };

  doCreateClick = (_: MouseEvent<HTMLButtonElement>): void => {
    // Verify that the user entered all required information.
    if (this.state.name.trim().length === 0 ||
        this.state.options.trim().length === 0 ||
        this.state.minutes.trim().length === 0) {
      this.setState({error: "a required field is missing."});
      return;
    }
    if(!hasAtLeastTwoLines(this.state.options.trim())){
        this.setState({error: "The options are not at least two lines"});
        return;
    }

    const repeats: boolean = hasRepeatedLines(this.state.options.trim());
    if(repeats){
      this.setState({error: "Duplicate options are not permitted"});
      return;
    }

    const minutes = parseFloat(this.state.minutes);
    if (isNaN(minutes) || minutes < 1 || Math.floor(minutes) !== minutes) {
      this.setState({error: "minutes is not a positive integer"});
      return;
    }
    
    const args = {name: this.state.name,
        options: stringToOptions(this.state.options), minutes: minutes};
    fetch("/api/add", {
        method: "POST", body: JSON.stringify(args),
        headers: {"Content-Type": "application/json"} })
      .then(this.doAddResp)
      .catch(() => this.doAddError("failed to connect to server"));
  };

  doAddResp = (resp: Response): void => {
    if (resp.status === 200) {
      resp.json().then(this.doAddJson)
          .catch(() => this.doAddError("200 response is not JSON"));
    } else if (resp.status === 400) {
      resp.text().then(this.doAddError)
          .catch(() => this.doAddError("400 response is not text"));
    } else {
      this.doAddError(`bad status code from /api/add: ${resp.status}`);
    }
  };

  doAddJson = (data: unknown): void => {
    if (!isRecord(data)) {
      console.error("bad data from /api/add: not a record", data);
      return;
    }

    this.props.onCreateClick(this.state.name);  
  };

  doAddError = (msg: string): void => {
    if(msg === `poll for '${this.state.name}' already exists`){
      this.setState({error: msg});
    } else {
      console.error(`Error fetching /api/add: ${msg}`);
    }
  };

  doBackClick = (_: MouseEvent<HTMLButtonElement>): void => {
    this.props.onBackClick();  
  };

}
/** Determines whether a string has at least two lines or not
 * @param input the string to be examined
 * @returns true if there are at least two lines and false if there isn't
 */
export const hasAtLeastTwoLines = (input: string): boolean => {
    const lines = input.split('\n');
    if(lines.length >= 2){
        return true;
    }
    return false;
}

/**
 * Returns the set of repeated lines in a string
 * @param string input
 * @returns true if there are no repeated lines and false otherwise
*/
export const hasRepeatedLines = (input: string): boolean => {
  const lines = input.split('\n');
  const set = new Set<string>();
    for (const line of lines) {
        if (set.has(line)) {
            return true;
        }
        set.add(line);
    }
    return false;
}

/** Turns a string of lines into an array of Options
* @param input the string to be examined
* @returns an array of Options
* @throws Error if the input has less than two lines
*/
export const stringToOptions = (input: string): Option[] => {
    const lines = input.split('\n');
    const optionArray: Option[] = [];
    if(lines.length < 2){
        throw Error("impossible: there aren't at least two lines")
    }
    for(const line of lines){
        const option: Option = {name: line, stat: 0, voteNum: 0};
        optionArray.push(option);
    }
    return optionArray;

}