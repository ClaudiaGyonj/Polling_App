import React, { Component, MouseEvent } from 'react';
import { Poll, parsePoll } from './poll';
import { isRecord } from './record';

type ListProps = {
    onNewClick: () => void,
    onPollClick: (name: string) => void
};
  
type ListState = {
    now: number,  // current time when rendering
    closedPolls: Poll[] | undefined,
    openPolls: Poll[] | undefined
};
  
  
// Shows the list of all the polls.
export class PollList extends Component<ListProps, ListState> {
  
    constructor(props: ListProps) {
        super(props);
        this.state = {now: Date.now(), closedPolls: undefined, openPolls: undefined};
    }
  
    componentDidMount = (): void => {
        this.doRefreshClick();
    }
  
    componentDidUpdate = (prevProps: ListProps): void => {
        if (prevProps !== this.props) {
            this.setState({now: Date.now()});  // Force a refresh
        }
    };

    render = (): JSX.Element => {
        return (
            <div>
            <h2>Current Polls</h2>
            <h3>Still Open</h3>
            {this.renderOpenPolls(this.state.openPolls)}
            <h3>Closed</h3>
            {this.renderClosedPolls(this.state.closedPolls)}
            <button type="button" onClick={this.doRefreshClick}>Refresh</button>
            <button type="button" onClick={this.doNewClick}>New Poll</button>
            </div>);
    };

    renderOpenPolls = (pollList: Poll[] | undefined): JSX.Element => {
        if (pollList === undefined) {
          return <p>Loading open poll list...</p>;
        } else {
          const polls: JSX.Element[] = [];
          for (const poll of pollList) {
            const min = Math.round((poll.endTime - this.state.now) / 60 / 100) / 10;
            polls.push(
              <li key={min}>
                <a href="#" onClick={(evt) => this.doPollClick(evt, poll.name)}>{poll.name}</a>
                <p><i>- {min} minutes remaining</i></p>  
              </li>);
          }
          return <ul>{polls}</ul>
        }
    };

    renderClosedPolls = (pollList: Poll[] | undefined): JSX.Element => {
      if (pollList === undefined) {
        return <p>Loading open poll list...</p>;
      } else {
        const polls: JSX.Element[] = [];
        for (const poll of pollList) {
          const min =  Math.abs(Math.round((poll.endTime - this.state.now) / 60 / 100) / 10);
          polls.push(
            <li key={min}>
              <a href="#" onClick={(evt) => this.doPollClick(evt, poll.name)}>{poll.name}</a>
              <p><i>- closed {min} minutes ago</i></p>      
            </li>);
        }
        return <ul>{polls}</ul>
      }
  };

    doRefreshClick = (): void => {
        fetch("/api/list").then(this.doListResp)
            .catch(() => this.doListError("failed to connect to server"));
    };

    doListResp = (resp: Response): void => {
        if (resp.status === 200) {
          resp.json().then(this.doListJson)
              .catch(() => this.doListError("200 response is not JSON"));
        } else if (resp.status === 400) {
          resp.text().then(this.doListError)
              .catch(() => this.doListError("400 response is not text"));
        } else {
          this.doListError(`bad status code from /api/list: ${resp.status}`);
        }
    };

    doListJson = (data: unknown): void => {
        if (!isRecord(data)) {
          console.error("bad data from /api/list: not a record", data);
          return;
        }
    
        if (!Array.isArray(data.openPolls)) {
          console.error("bad data from /api/list: open polls is not an array", data);
          return;
        }

        if (!Array.isArray(data.closedPolls)) {
            console.error("bad data from /api/list: closed polls is not an array", data);
            return;
          }
    
        const openPolls: Poll[] = [];
        for (const val of data.openPolls) {
          const poll = parsePoll(val);
          if (poll === undefined){
            return;
          }
          openPolls.push(poll);
        }

        const closedPolls: Poll[] = [];
        for (const val of data.closedPolls) {
          const poll = parsePoll(val);
          if (poll === undefined){
            return;
          }
          closedPolls.push(poll);
        }
    
        this.setState({now: Date.now(), closedPolls: closedPolls, openPolls: openPolls});
    };
    
    doListError = (msg: string): void => {
        console.error(`Error fetching /api/list: ${msg}`);
    };

    doNewClick = (_evt: MouseEvent<HTMLButtonElement>): void => {
        this.props.onNewClick();
    };    

    doPollClick = (evt: MouseEvent<HTMLAnchorElement>, name: string): void => {
        evt.preventDefault();
        this.props.onPollClick(name);
    };

}