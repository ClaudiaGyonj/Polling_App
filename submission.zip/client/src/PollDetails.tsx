import React, { Component, ChangeEvent, MouseEvent } from 'react';
import { Poll, parsePoll } from './poll';
import { isRecord } from './record';


type DetailsProps = {
  name: string,
  onBackClick: () => void,
};

type DetailsState = {
  now: number,
  poll: Poll | undefined,
  voter: string,
  optionSelected: string,
  error: string,
  validVote: boolean
};


// Shows an individual poll and allows voting (if ongoing).
export class PollDetails extends Component<DetailsProps, DetailsState> {

  constructor(props: DetailsProps) {
    super(props);

    this.state = {now: Date.now(), poll: undefined,
                  voter: "", optionSelected: "", error: "", validVote: false};
  }

  componentDidMount = (): void => {
    this.doRefreshClick(); 
  };

  render = (): JSX.Element => {
    if (this.state.poll === undefined) {
      return <p>Loading poll "{this.props.name}"...</p>
    } else {
      if (this.state.poll.endTime <= this.state.now) {
        return this.renderCompleted(this.state.poll);
      } else {
        return this.renderOngoing(this.state.poll);
      }
    }
  };

  renderCompleted = (poll: Poll): JSX.Element => {
    const min = Math.abs(Math.round((poll.endTime - this.state.now) / 60 / 100) / 10);
    return (
        <div>
            <h2>{poll.name}</h2>
            <p><i>Closed {min} minutes ago.</i></p>
            <ul>
                {this.renderStats()}
            </ul>
            <button type="button" onClick={this.doBackClick}>Back</button>
            <button type="button" onClick={this.doRefreshClick}>Refresh</button>
        </div>
    );
  };

  renderStats = (): JSX.Element => {
    if(this.state.poll === undefined){
        return <p>Loading list of options...</p>
      } else {
        const options: JSX.Element[] = [];
        for(const option of this.state.poll.options){
          options.push(
            <li key={`${option.name}${Date.now() - 1}${this.state.poll}`}>
                <p>{option.stat}% - {option.name}</p>
            </li>
          )
        }
        return <div>{options}</div>
      }

  }


  renderOngoing = (poll: Poll): JSX.Element => {
    const min = Math.round((poll.endTime - this.state.now) / 60 / 100) / 10;
    return (
        <div>
            <h2>{poll.name}</h2>
            <p><i>Closes in {min} minutes...</i></p>
            <ul>
                {this.renderOptions()}
            </ul>
            <div>
                <label htmlFor="name">Voter name:</label>
                <input id="name" type="text" value={this.state.voter}
                    onChange={this.doVoterChange}></input>
            </div>
            
            <button type="button" onClick={this.doBackClick}>Back</button>
            <button type="button" onClick={this.doRefreshClick}>Refresh</button>
            <button type="button" onClick={this.doVoteClick}>Vote</button>
           
            {this.renderConclusion()}
            {this.renderError()}
        </div>
    );
  };

  renderConclusion = (): JSX.Element => {
    if(this.state.validVote){
        return <p>Recorded vote of "{this.state.voter}" as "{this.state.optionSelected}"</p>
    } else {
        return <div></div>
    }
    
  };

  renderOptions = (): JSX.Element => {
    if (this.state.poll === undefined) {
        return <p>Loading options...</p>;
      } else {
        const options: JSX.Element[] = [];
        for (const option of this.state.poll.options) {
          options.push(
            <div key={`${option.name}${Date.now()}${this.state.poll}`}>
              <input type ="radio" id={option.name} name='item' value={option.name} checked={option.name === this.state.optionSelected} onChange={this.doOptionChange}/>
              <label htmlFor={option.name}>{option.name}</label>
            </div>);
        }
        return <div>{options}</div>;
      }
  };

  renderError = (): JSX.Element => {
    if (this.state.error.length === 0) {
      return <div></div>;
    } else {
      const style = {width: '300px', backgroundColor: 'rgb(246,194,192)',
          border: '1px solid rgb(137,66,61)', borderRadius: '5px', padding: '5px' };
      return (<div style={{marginTop: '15px'}}>
          <span style={style}><b>Error</b>: {this.state.error}</span>
        </div>);
    }
  };

  doRefreshClick = (): void => {
    fetch("/api/get?name=" + this.props.name)
      .then(this.doGetResp)
      .catch(() => this.doGetError("failed to connect to server"));
  };

  doGetResp = (res: Response): void => {
    if (res.status === 200) {
      res.json().then(this.doGetJson)
          .catch(() => this.doGetError("200 res is not JSON"));
    } else if (res.status === 400) {
      res.text().then(this.doGetError)
          .catch(() => this.doGetError("400 response is not text"));
    } else {
      this.doGetError(`bad status code from /api/get: ${res.status}`);
    }
  };

  doGetJson = (data: unknown): void => {
    if(!isRecord(data)){
        console.error("bad data from /api/get: not a record", data);
        return;
    }

    this.doPollChange(data);
  };

  doPollChange = (data: {poll?: unknown}): void => {
    const poll = parsePoll(data.poll);
    if (poll !== undefined) {
        this.setState({poll: poll, now: Date.now(), error: "",});
    } else {
      console.error("poll from /api/get did not parse", data.poll)
    }
  };

  doGetError = (msg: string): void => {
    console.error(`Error fetching /api/get: ${msg}`);
  };

  doVoterChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({voter: evt.target.value, error: ""});
  };

  doOptionChange = (evt: ChangeEvent<HTMLInputElement>): void => {
    this.setState({optionSelected: evt.target.value, error: ""});
  };

  doVoteClick = (_: MouseEvent<HTMLButtonElement>): void => {
    if (this.state.poll === undefined){
      throw new Error("impossible");
    }
    if (this.state.voter.trim().length === 0 ||
        this.state.optionSelected.trim().length === 0) {
      this.setState({error: "a required field is missing."});
      return;
    }

    const args = {name: this.props.name, voter: this.state.voter, optionSelected: this.state.optionSelected};
    fetch("/api/vote", {
        method: "POST", body: JSON.stringify(args),
        headers: {"Content-Type": "application/json"} })
      .then(this.doVoteResp)
      .catch(() => this.doVoteError("failed to connect to server"));
  };

  doVoteResp = (res: Response): void => {
    if (res.status === 200) {
      res.json().then(this.doVoteJson)
          .catch(() => this.doVoteError("200 response is not JSON"));
    } else if (res.status === 400) {
      res.text().then(this.doVoteError)
          .catch(() => this.doVoteError("400 response is not text"));
    } else {
      this.doVoteError(`bad status code from /api/vote: ${res.status}`);
    }
  };

  doVoteJson = (data: unknown): void => {
    if (this.state.poll === undefined)
      throw new Error("impossible");

    if (!isRecord(data)) {
      console.error("bad data from /api/vote: not a record", data);
      return;
    }
    this.setState({validVote: true})
    this.doPollChange(data);
  };

  doVoteError = (msg: string): void => {
    if (this.state.poll === undefined){
      throw new Error("impossible");
    }
    if(msg === `poll for "${this.state.poll.name}" has already ended`){
      this.setState({error: `${msg}. Click 'refresh' if you would like to see the results. `});
    } else {
      console.error(`Error fetching /api/vote: ${msg}`);
    }
  };

  doBackClick = (_: MouseEvent<HTMLButtonElement>): void => {
    this.props.onBackClick();  // tell the parent to show the full list again
  };

}


