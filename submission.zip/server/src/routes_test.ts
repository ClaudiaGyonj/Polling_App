import * as assert from 'assert';
import * as httpMocks from 'node-mocks-http';
import { getPoll, vote, addPoll, listPolls, resetForTesting, advanceTimeForTesting, findOption } from './routes';


describe('routes', function() {


  it('getPoll', function() {
    const req1 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "couch", options: [{name: "a couch", stat: 0, voteNum: 0}, {name: "hi", stat: 0, voteNum: 0}],
              minutes: 5}});
    const res1 = httpMocks.createResponse();
    addPoll(req1, res1);

    const req2 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "chair", options: [{name: "comfy", stat: 0, voteNum: 0}, {name: "chair", stat: 0, voteNum: 0}],
              minutes: 10}});
    const res2 = httpMocks.createResponse();
    addPoll(req2, res2);

    // 1. Missing name
    const req3 = httpMocks.createRequest(
      {method: 'GET', url: '/api/get', query: {}});
    const res3 = httpMocks.createResponse();
    getPoll(req3, res3);
    assert.strictEqual(res3._getStatusCode(), 400);
    assert.deepStrictEqual(res3._getData(),
      "missing or invalid 'name' parameter");

    // 2. Invalid name
    const req4 = httpMocks.createRequest(
      {method: 'GET', url: '/api/get',
       query: {name: "fridge"}});
    const res4 = httpMocks.createResponse();
    getPoll(req4, res4);
    assert.strictEqual(res4._getStatusCode(), 400);
    assert.deepStrictEqual(res4._getData(), "no poll with name 'fridge'");

    const req5 = httpMocks.createRequest(
      {method: 'GET', url: '/api/get',
       query: {name: "stool"}});
    const res5 = httpMocks.createResponse();
    getPoll(req5, res5);
    assert.strictEqual(res5._getStatusCode(), 400);
    assert.deepStrictEqual(res5._getData(), "no poll with name 'stool'");

    // 3. Poll found
    const req6 = httpMocks.createRequest(
      {method: 'GET', url: '/api/get', query: {name: "couch"}});
    const res6 = httpMocks.createResponse();
    getPoll(req6, res6);
    assert.strictEqual(res6._getStatusCode(), 200);
    assert.deepStrictEqual(res6._getData().poll.name, "couch");
    assert.deepStrictEqual(res6._getData().poll.options, [{name: "a couch", stat: 0, voteNum: 0}, {name: "hi", stat: 0, voteNum: 0}]);

    const req7 = httpMocks.createRequest(
      {method: 'GET', url: '/api/get', query: {name: "chair"}});
    const res7 = httpMocks.createResponse();
    getPoll(req7, res7);
    assert.strictEqual(res7._getStatusCode(), 200);
    assert.deepStrictEqual(res7._getData().poll.name, "chair");
    assert.deepStrictEqual(res7._getData().poll.options, [{name: "comfy", stat: 0, voteNum: 0}, {name: "chair", stat: 0, voteNum: 0}]);

    resetForTesting();
  });

  it('vote', function() {
    const req1 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "couch", options: [{name: "a couch", stat: 0, voteNum: 0}, {name: "a bird", stat: 0, voteNum: 0}, {name: "a cat", stat: 0, voteNum: 0}], minutes: 5}});
    const res1 = httpMocks.createResponse();
    addPoll(req1, res1);

    // Separate domain for each branch:
    // 1. Missing optionSelected
    const req2 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote', body: {name: "hi", voter: "hi"}});
    const res2 = httpMocks.createResponse();
    vote(req2, res2);
    assert.strictEqual(res2._getStatusCode(), 400);
    assert.deepStrictEqual(res2._getData(),
      "missing or invalid 'optionSelected' parameter");

    // 2. Missing name
    const req3 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote', body: {voter: "Barney", optionSelected: "no"}});
    const res3 = httpMocks.createResponse();
    vote(req3, res3);
    assert.strictEqual(res3._getStatusCode(), 400);
    assert.deepStrictEqual(res3._getData(),
      "missing or invalid 'name' parameter");

    // 2. Missing voter
    const req4 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote', body: {name: "hi", optionSelected: "no"}});
    const res4 = httpMocks.createResponse();
    vote(req4, res4);
    assert.strictEqual(res4._getStatusCode(), 400);
    assert.deepStrictEqual(res4._getData(),
      "missing or invalid 'voter' parameter");

    // 3. Invalid name
    const req5 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "chair", voter: "hi", optionSelected: "no"}});
    const res5 = httpMocks.createResponse();
    vote(req5, res5);
    assert.strictEqual(res5._getStatusCode(), 400);
    assert.deepStrictEqual(res5._getData(), "no poll with name 'chair'");

    const req6 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "stool", voter: "me", optionSelected: "yes"}});
    const res6 = httpMocks.createResponse();
    vote(req6, res6);
    assert.strictEqual(res6._getStatusCode(), 400);
    assert.deepStrictEqual(res6._getData(), "no poll with name 'stool'");

    //Option not found
    const req7 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "me", optionSelected: "couch"}});
    const res7 = httpMocks.createResponse();
    vote(req7, res7);
    assert.strictEqual(res7._getStatusCode(), 400);
    assert.deepStrictEqual(res7._getData(), "optionSelected doesn't exist in poll");
    
    //Vote made
    const req8 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "me", optionSelected: "a couch"}});
    const res8 = httpMocks.createResponse();
    vote(req8, res8);
    assert.strictEqual(res8._getStatusCode(), 200);
    assert.deepStrictEqual(res8._getData().poll.name, "couch");
    assert.deepStrictEqual(res8._getData().poll.options, [{name: "a couch", stat: 100, voteNum: 1}, {name: "a bird", stat: 0, voteNum: 0}, {name: "a cat", stat: 0, voteNum: 0}]);

    //Another vote made
    const req9 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "you", optionSelected: "a bird"}});
    const res9 = httpMocks.createResponse();
    vote(req9, res9);
    assert.strictEqual(res9._getStatusCode(), 200);
    assert.deepStrictEqual(res9._getData().poll.name, "couch");
    assert.deepStrictEqual(res9._getData().poll.options, [{name: "a couch", stat: 50, voteNum: 1 }, {name: "a bird", stat: 50, voteNum: 1}, {name: "a cat", stat: 0, voteNum: 0}]);

    //Same person voted again
    const req10 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "me", optionSelected: "a bird"}});
    const res10 = httpMocks.createResponse();
    vote(req10, res10);
    assert.strictEqual(res10._getStatusCode(), 200);
    assert.deepStrictEqual(res10._getData().poll.name, "couch");
    assert.deepStrictEqual(res10._getData().poll.options, [{name: "a couch", stat: 0, voteNum: 0}, {name: "a bird", stat: 100, voteNum: 2}, {name: "a cat", stat: 0, voteNum: 0}]);

    //Same person voted again on the same option
    const req11 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "me", optionSelected: "a bird"}});
    const res11 = httpMocks.createResponse();
    vote(req11, res11);
    assert.strictEqual(res11._getStatusCode(), 200);
    assert.deepStrictEqual(res11._getData().poll.name, "couch");
    assert.deepStrictEqual(res11._getData().poll.options, [{name: "a couch", stat: 0, voteNum: 0}, {name: "a bird", stat: 100, voteNum: 2}, {name: "a cat", stat: 0, voteNum: 0}]);

    //Same person voted again on a different option
    const req12 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "you", optionSelected: "a cat"}});
    const res12 = httpMocks.createResponse();
    vote(req12, res12);
    assert.strictEqual(res12._getStatusCode(), 200);
    assert.deepStrictEqual(res12._getData().poll.name, "couch");
    assert.deepStrictEqual(res12._getData().poll.options, [{name: "a couch", stat: 0, voteNum: 0}, {name: "a bird", stat: 50, voteNum: 1}, {name: "a cat", stat: 50, voteNum: 1}]);

    //Same person voted again on a different option
    const req13 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "me", optionSelected: "a cat"}});
    const res13 = httpMocks.createResponse();
    vote(req13, res13);
    assert.strictEqual(res13._getStatusCode(), 200);
    assert.deepStrictEqual(res13._getData().poll.name, "couch");
    assert.deepStrictEqual(res13._getData().poll.options, [{name: "a couch", stat: 0, voteNum: 0}, {name: "a bird", stat: 0, voteNum: 0}, {name: "a cat", stat: 100, voteNum: 2}]);

    //Third person voted on a different option
    const req14 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "somebody", optionSelected: "a couch"}});
    const res14 = httpMocks.createResponse();
    vote(req14, res14);
    assert.strictEqual(res14._getStatusCode(), 200);
    assert.deepStrictEqual(res14._getData().poll.name, "couch");
    assert.deepStrictEqual(res14._getData().poll.options, [{name: "a couch", stat: 33, voteNum: 1}, {name: "a bird", stat: 0, voteNum: 0}, {name: "a cat", stat: 67, voteNum: 2}]);
    
    //Third person voted again on a different option
    const req15 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "somebody", optionSelected: "a bird"}});
    const res15 = httpMocks.createResponse();
    vote(req15, res15);
    assert.strictEqual(res15._getStatusCode(), 200);
    assert.deepStrictEqual(res15._getData().poll.name, "couch");
    assert.deepStrictEqual(res15._getData().poll.options, [{name: "a couch", stat: 0, voteNum: 0}, {name: "a bird", stat: 33, voteNum: 1}, {name: "a cat", stat: 67, voteNum: 2}]);

    //Fourth person voted on a different option
    const req16 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "they", optionSelected: "a couch"}});
    const res16 = httpMocks.createResponse();
    vote(req16, res16);
    assert.strictEqual(res16._getStatusCode(), 200);
    assert.deepStrictEqual(res16._getData().poll.name, "couch");
    assert.deepStrictEqual(res16._getData().poll.options, [{name: "a couch", stat: 25, voteNum: 1}, {name: "a bird", stat: 25, voteNum: 1}, {name: "a cat", stat: 50, voteNum: 2}]);

    //Adding another poll
    const req18 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "hi", options: [{name: "a cave", stat: 0, voteNum: 0}, {name: "a stat", stat: 0, voteNum: 0}], minutes: 5}});
    const res18 = httpMocks.createResponse();
    addPoll(req18, res18);

    //First vote
    const req19 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "hi", voter: "dad", optionSelected: "a cave"}});
    const res19 = httpMocks.createResponse();
    vote(req19, res19);
    assert.strictEqual(res19._getStatusCode(), 200);
    assert.deepStrictEqual(res19._getData().poll.name, "hi");
    assert.deepStrictEqual(res19._getData().poll.options, [{name: "a cave", stat: 100, voteNum: 1}, {name: "a stat", stat: 0, voteNum: 0}]);

    //Second person votes
    const req20 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "hi", voter: "they", optionSelected: "a stat"}});
    const res20 = httpMocks.createResponse();
    vote(req20, res20);
    assert.strictEqual(res20._getStatusCode(), 200);
    assert.deepStrictEqual(res20._getData().poll.name, "hi");
    assert.deepStrictEqual(res20._getData().poll.options, [{name: "a cave", stat: 50, voteNum: 1}, {name: "a stat", stat: 50, voteNum: 1}]);

    //Second person votes again
    const req21 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "hi", voter: "they", optionSelected: "a cave"}});
    const res21 = httpMocks.createResponse();
    vote(req21, res21);
    assert.strictEqual(res21._getStatusCode(), 200);
    assert.deepStrictEqual(res21._getData().poll.name, "hi");
    assert.deepStrictEqual(res21._getData().poll.options, [{name: "a cave", stat: 100, voteNum: 2}, {name: "a stat", stat: 0, voteNum: 0}]);

    //Third person votes
    const req22 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "hi", voter: "he", optionSelected: "a stat"}});
    const res22 = httpMocks.createResponse();
    vote(req22, res22);
    assert.strictEqual(res22._getStatusCode(), 200);
    assert.deepStrictEqual(res22._getData().poll.name, "hi");
    assert.deepStrictEqual(res22._getData().poll.options, [{name: "a cave", stat: 67, voteNum: 2}, {name: "a stat", stat: 33, voteNum: 1}]);

    //Another poll added
    const req23 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "water", options: [{name: "a cave", stat: 0, voteNum: 0}, {name: "a stat", stat: 0, voteNum: 0}], minutes: 5}});
    const res23 = httpMocks.createResponse();
    addPoll(req23, res23);
    //Person that voted on a different poll votes on this one
    const req24 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "water", voter: "he", optionSelected: "a stat"}});
    const res24 = httpMocks.createResponse();
    vote(req24, res24);
    assert.strictEqual(res24._getStatusCode(), 200);
    assert.deepStrictEqual(res24._getData().poll.name, "water");
    assert.deepStrictEqual(res24._getData().poll.options, [{name: "a cave", stat: 0, voteNum: 0}, {name: "a stat", stat: 100, voteNum: 1}]);
    //Same person votes again
    const req25 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "water", voter: "he", optionSelected: "a cave"}});
    const res25 = httpMocks.createResponse();
    vote(req25, res25);
    assert.strictEqual(res25._getStatusCode(), 200);
    assert.deepStrictEqual(res25._getData().poll.name, "water");
    assert.deepStrictEqual(res25._getData().poll.options, [{name: "a cave", stat: 100, voteNum: 1}, {name: "a stat", stat: 0, voteNum: 0}]);
    //testing if old polls are preserved
    assert.deepStrictEqual(res22._getData().poll.name, "hi");
    assert.deepStrictEqual(res22._getData().poll.options, [{name: "a cave", stat: 67, voteNum: 2}, {name: "a stat", stat: 33, voteNum: 1}]);
    assert.deepStrictEqual(res16._getData().poll.name, "couch");
    assert.deepStrictEqual(res16._getData().poll.options, [{name: "a couch", stat: 25, voteNum: 1}, {name: "a bird", stat: 25, voteNum: 1}, {name: "a cat", stat: 50, voteNum: 2}]);
    //Vote in old poll
    const req26 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote',
       body: {name: "couch", voter: "mom", optionSelected: "a bird"}});
    const res26 = httpMocks.createResponse();
    vote(req26, res26);
    assert.strictEqual(res26._getStatusCode(), 200);
    assert.deepStrictEqual(res26._getData().poll.name, "couch");
    assert.deepStrictEqual(res26._getData().poll.options, [{name: "a couch", stat: 20, voteNum: 1}, {name: "a bird", stat: 40, voteNum: 2}, {name: "a cat", stat: 40, voteNum: 2}]);


    // Push time forward by over 5 minutes
    advanceTimeForTesting(5 * 60 * 1000 + 50);

    const req17 = httpMocks.createRequest(
      {method: 'POST', url: '/api/vote', 
      body: {name: "couch", voter: "they", optionSelected: "a couch"}});
    const res17 = httpMocks.createResponse();
    vote(req17, res17);
    assert.strictEqual(res17._getStatusCode(), 400);
    assert.deepStrictEqual(res17._getData(),
    "poll for \"couch\" has already ended");

    resetForTesting();
  });

  it('findOption', function() {
    //0 loops, first test case
    assert.deepStrictEqual(findOption("hi", {name: "hi", options: [], endTime: 20}), undefined);
    //0 loops, second test case
    assert.deepStrictEqual(findOption("no", {name: "bye", options: [], endTime: 15}), undefined);
    //1 loop, first test case
    assert.deepStrictEqual(findOption("no", {name: "bye", options: [{name: "no", stat: 20, voteNum: 20}], endTime: 15}), {name: "no", stat: 20, voteNum: 20});
    //1 loop, second test case
    assert.deepStrictEqual(findOption("yes", {name: "bye", options: [{name: "yes", stat: 20, voteNum: 20}], endTime: 15}), {name: "yes", stat: 20, voteNum: 20});
    //1 loops, third test case
    assert.deepStrictEqual(findOption("no", {name: "bye", options: [{name: "yes", stat: 20, voteNum: 20}], endTime: 15}), undefined);
    //1 loop, fourth test case
    assert.deepStrictEqual(findOption("go", {name: "bye", options: [{name: "back", stat: 20, voteNum: 20}], endTime: 15}), undefined);
    //2 loops, first test case
    assert.deepStrictEqual(findOption("no", {name: "bye", options: [{name: "no", stat: 20, voteNum: 20}, {name: "yes", stat: 20, voteNum: 20}], endTime: 15}), {name: "no", stat: 20, voteNum: 20});
    //2 loops, second test case
    assert.deepStrictEqual(findOption("yes", {name: "bye", options: [{name: "no", stat: 20, voteNum: 20}, {name: "yes", stat: 20, voteNum: 20}], endTime: 15}), {name: "yes", stat: 20, voteNum: 20});
    //2 loops, third test case
    assert.deepStrictEqual(findOption("no", {name: "bye", options: [{name: "hi", stat: 20, voteNum: 20}, {name: "yes", stat: 20, voteNum: 20}], endTime: 15}), undefined);
    //2 loops, fourth test case
    assert.deepStrictEqual(findOption("yes", {name: "bye", options: [{name: "no", stat: 20, voteNum: 20}, {name: "hi", stat: 20, voteNum: 20}], endTime: 15}), undefined);
  });

  it('addPoll', function() {
    // Separate domain for each branch:
    // 1. Missing name
    const req1 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add', body: {}});
    const res1 = httpMocks.createResponse();
    addPoll(req1, res1);
    assert.strictEqual(res1._getStatusCode(), 400);
    assert.deepStrictEqual(res1._getData(),
      "missing 'name' parameter");

    // 3. Missing options
    const req3 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "couch"}});
    const res3 = httpMocks.createResponse();
    addPoll(req3, res3);
    assert.strictEqual(res3._getStatusCode(), 400);
    assert.deepStrictEqual(res3._getData(),
      "missing 'options' parameter");

    const req3part2 = httpMocks.createRequest(
        {method: 'POST', url: '/api/add',
         body: {name: "couch", options: [{name: 0, stat: 0}]}});
    const res3part2 = httpMocks.createResponse();
    addPoll(req3part2, res3part2);
    assert.strictEqual(res3part2._getStatusCode(), 400);
    assert.deepStrictEqual(res3part2._getData(),
        "missing 'options' parameter");

    // 6. Missing minutes
    const req7 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "couch", options: [{name: "a couch", stat: 0, voteNum: 0}, {name: "hi", stat: 0, voteNum: 0}]}});
    const res7 = httpMocks.createResponse();
    addPoll(req7, res7);
    assert.strictEqual(res7._getStatusCode(), 400);
    assert.deepStrictEqual(res7._getData(),
      "'minutes' is not a number: undefined");

    // 7. Invalid minutes
    const req8 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "couch", options: [{name: "a couch", stat: 0, voteNum: 0}, {name: "hi", stat: 0, voteNum: 0}], minutes: 0}});
    const res8 = httpMocks.createResponse();
    addPoll(req8, res8);
    assert.strictEqual(res8._getStatusCode(), 400);
    assert.deepStrictEqual(res8._getData(),
      "'minutes' is not a positive integer: 0");

    const req9 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "couch", options: [{name: "a couch", stat: 0, voteNum: 0}, {name: "hi", stat: 0, voteNum: 0}], minutes: 3.5}});
    const res9 = httpMocks.createResponse();
    addPoll(req9, res9);
    assert.strictEqual(res9._getStatusCode(), 400);
    assert.deepStrictEqual(res9._getData(),
      "'minutes' is not a positive integer: 3.5");

    // 8. Correctly added
    const req10 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "couch", options: [{name: "a couch", stat: 0, voteNum: 0}, {name: "hi", stat: 0, voteNum: 0}], minutes: 4}});
    const res10 = httpMocks.createResponse();
    addPoll(req10, res10);
    assert.strictEqual(res10._getStatusCode(), 200);
    assert.deepStrictEqual(res10._getData().poll.name, "couch");
    assert.deepStrictEqual(res10._getData().poll.options, [{name: "a couch", stat: 0, voteNum: 0}, {name: "hi", stat: 0, voteNum: 0}]);
    const endTime10 = res10._getData().poll.endTime;
    assert.ok(Math.abs(endTime10 - Date.now() - 4 * 60 * 1000) < 50);

    const req11 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "chair", options: [{name: "hi", stat: 0, voteNum: 0}, {name: "you", stat: 0, voteNum: 0}], minutes: 2}});
    const res11 = httpMocks.createResponse();
    addPoll(req11, res11);
    assert.strictEqual(res11._getStatusCode(), 200);
    assert.deepStrictEqual(res11._getData().poll.name, "chair");
    assert.deepStrictEqual(res11._getData().poll.options, [{name: "hi", stat: 0, voteNum: 0}, {name: "you", stat: 0, voteNum: 0}]);
    const endTime11 = res11._getData().poll.endTime;
    assert.ok(Math.abs(endTime11 - Date.now() - 2 * 60 * 1000) < 50);

    const req12 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "chair", options: [{name: "no", stat: 0, voteNum: 0}, {name: "you", stat: 0, voteNum: 0}], minutes: 2}});
    const res12 = httpMocks.createResponse();
    addPoll(req12, res12);
    assert.strictEqual(res12._getStatusCode(), 400);
    assert.deepStrictEqual(res12._getData(), 
    "poll for 'chair' already exists");

    resetForTesting();
  });

  it('listPolls', function() {
    const req1 = httpMocks.createRequest(
      {method: 'GET', url: '/api/list', query: {}});
    const res1 = httpMocks.createResponse();
    listPolls(req1, res1);
    assert.strictEqual(res1._getStatusCode(), 200);
    assert.deepStrictEqual(res1._getData(), {openPolls: [], closedPolls: []});

    const req2 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "couch", options: [{name: "a couch", stat: 0, voteNum: 0}, {name: "hi", stat: 0, voteNum: 0}], 
       minutes: 10}});
    const res2 = httpMocks.createResponse();
    addPoll(req2, res2);

    const req3 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "chair", options: [{name: "comfy", stat: 0, voteNum: 0}, {name: "chair", stat: 0, voteNum: 0}], 
       minutes: 5}});
    const res3 = httpMocks.createResponse();
    addPoll(req3, res3);

    const req4 = httpMocks.createRequest(
      {method: 'POST', url: '/api/add',
       body: {name: "stool", options: [{name: "hi", stat: 0, voteNum: 0}, {name: "you", stat: 0, voteNum: 0}], 
       minutes: 15}});
    const res4 = httpMocks.createResponse();
    addPoll(req4, res4);

    // NOTE: chair goes first because it finishes sooner
    const req5 = httpMocks.createRequest(
      {method: 'GET', url: '/api/list', query: {}});
    const res5 = httpMocks.createResponse();
    listPolls(req5, res5);
    assert.strictEqual(res5._getStatusCode(), 200);
    assert.deepStrictEqual(res5._getData().openPolls.length, 3);
    assert.deepStrictEqual(res5._getData().openPolls[0].name, "chair");
    assert.deepStrictEqual(res5._getData().openPolls[1].name, "couch");
    assert.deepStrictEqual(res5._getData().openPolls[2].name, "stool");
    assert.deepStrictEqual(res5._getData().closedPolls.length, 0);

    // Push time forward by over 5 minutes
    advanceTimeForTesting(5 * 60 * 1000 + 50); 
       
    // NOTE: chair goes after because it has finished
    const req6 = httpMocks.createRequest(
     {method: 'GET', url: '/api/list', query: {}});
    const res6 = httpMocks.createResponse();
    listPolls(req6, res6);
    assert.strictEqual(res6._getStatusCode(), 200);
    assert.deepStrictEqual(res6._getData().openPolls.length, 2);
    assert.deepStrictEqual(res6._getData().openPolls[0].name, "couch");
    assert.deepStrictEqual(res6._getData().openPolls[1].name, "stool");
    assert.deepStrictEqual(res6._getData().closedPolls.length, 1);
    assert.deepStrictEqual(res6._getData().closedPolls[0].name, "chair");
     
    // Push time forward by another 5 minutes
    advanceTimeForTesting(5 * 60 * 1000);
 
    // NOTE: chair stays after because it finished first
    const req7 = httpMocks.createRequest(
     {method: 'GET', url: '/api/list', query: {}});
    const res7 = httpMocks.createResponse();
    listPolls(req7, res7);
    assert.strictEqual(res7._getStatusCode(), 200);
    assert.deepStrictEqual(res7._getData().openPolls.length, 1);
    assert.deepStrictEqual(res7._getData().openPolls[0].name, "stool");
    assert.deepStrictEqual(res7._getData().closedPolls.length, 2);
    assert.deepStrictEqual(res7._getData().closedPolls[0].name, "couch");
    assert.deepStrictEqual(res7._getData().closedPolls[1].name, "chair");

    // Push time forward by another 20 minutes (all are completed)
    advanceTimeForTesting(20 * 60 * 1000);
 
    // NOTE: chair stays after because it finished first
    const req8 = httpMocks.createRequest(
     {method: 'GET', url: '/api/list', query: {}});
    const res8 = httpMocks.createResponse();
    listPolls(req8, res8);
    assert.strictEqual(res8._getStatusCode(), 200);
    assert.deepStrictEqual(res8._getData().closedPolls.length, 3);
    assert.deepStrictEqual(res8._getData().openPolls.length, 0);
    assert.deepStrictEqual(res8._getData().closedPolls[0].name, "stool");
    assert.deepStrictEqual(res8._getData().closedPolls[1].name, "couch");
    assert.deepStrictEqual(res8._getData().closedPolls[2].name, "chair");

    resetForTesting();
  });

});
