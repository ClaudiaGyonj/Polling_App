import { Request, Response } from "express";
import { ParamsDictionary } from "express-serve-static-core";



// Require type checking of request body.
type SafeRequest = Request<ParamsDictionary, {}, Record<string, unknown>>;
type SafeResponse = Response;  // only writing, so no need to check

// Description of an individual poll
export type Poll = {
  name: string,
  options: Option[],
  endTime: number,  
};

//Description of an option
export type Option = {name: string, stat: number, voteNum: number};

//Description of option selected by voter
export type OptionSelected = {optionName: string, poll: Poll};

//maps poll name to corresponding poll
const polls: Map<string, Poll> = new Map();

//maps voter name to the option they most recently voted on
const votes: Map<string, OptionSelected[]> = new Map();


/** Testing function to remove all the added auctions. */
export const resetForTesting = (): void => {
  polls.clear();
  votes.clear();
};

/** Testing function to move all end times forward the given amount (of ms). */
export const advanceTimeForTesting = (ms: number): void => {
  for (const poll of polls.values()) {
    poll.endTime -= ms;
  }
};

// Sort auctions with the ones finishing soonest first, but with all those that
// are completed after those that are not and in reverse order by end time.
const comparePolls = (a: Poll, b: Poll): number => {
  const now: number = Date.now();
  const endA = now <= a.endTime ? a.endTime : 1e15 - a.endTime;
  const endB = now <= b.endTime ? b.endTime : 1e15 - b.endTime;
  return endA - endB;
};

/**
 * Returns a list of all the polls, sorted so that the ongoing auctions come
 * first, with the ones about to end listed first, and the completed ones after,
 * with the ones completed more recently
 * @param _req the request
 * @param res the response
 */
export const listPolls = (_req: SafeRequest, res: SafeResponse): void => {
  const vals = Array.from(polls.values());
  vals.sort(comparePolls);
  const openPolls: Poll[] = [];
  const closedPolls: Poll[] = [];
  for(const val of vals){
    if(val.endTime <= Date.now()){
      closedPolls.push(val);
    } else {
      openPolls.push(val);
    }
  }
        
  res.send({openPolls: openPolls, closedPolls: closedPolls});
};



/**
 * Add the poll to the list.
 * @param req the request
 * @param res the response
 */
export const addPoll = (req: SafeRequest, res: SafeResponse): void => {
  const name = req.body.name;
  if (typeof name !== 'string') {
    res.status(400).send("missing 'name' parameter");
    return;
  }

  const options = req.body.options;
  const parsedOptions: Option[] | undefined = parseOptions(options);
  if (parsedOptions === undefined) {
    res.status(400).send("missing 'options' parameter");
    return;
  }

  const minutes = req.body.minutes;
  if (typeof minutes !== "number") {
    res.status(400).send(`'minutes' is not a number: ${minutes}`);
    return;
  } else if (isNaN(minutes) || minutes < 1 || Math.round(minutes) !== minutes) {
    res.status(400).send(`'minutes' is not a positive integer: ${minutes}`);
    return;
  }

  if (polls.has(name)) {
    res.status(400).send(`poll for '${name}' already exists`);
    return;
  }

  const poll: Poll = {
    name: name,
    options: parsedOptions,
    endTime: Date.now() + minutes * 60 * 1000,  // convert to ms
  };
  polls.set(poll.name, poll); 
  res.send({poll: poll});  
};

/** Parses unknown data into an array of Options 
* @param val unknown data to parse into an array of Options
* @return array of Options if val is a valid and undefined otherwise
*/
export const parseOptions = (val: unknown): undefined | Option[] => {
  if (!Array.isArray(val)) {
      return undefined;
  }

  const options: Option[] = [];
  for (const item of val) {
      if (!isRecord(item)) {
          return undefined;
      } else if (typeof item.name !== 'string') {
          return undefined;
      } else if(typeof item.stat !== 'number'){
          return undefined;
      } else if(typeof item.voteNum !== 'number'){
          return undefined;
      } else {
          options.push({name: item.name, stat: item.stat, voteNum: item.voteNum});
      }
  }
  return options;
}


/**
 * Determines whether the given value is a record.
 * @param val the value in question
 * @return true if the value is a record and false otherwise
 */
export const isRecord = (val: unknown): val is Record<string, unknown> => {
  return val !== null && typeof val === "object";
};

/**
 * Votes in a poll, changing the statistic for the option that was voted on
 * @param req the request
 * @param req the response
 */
export const vote = (req: SafeRequest, res: SafeResponse): void => {
  const optionSelected = req.body.optionSelected;
  if (typeof optionSelected !== "string") {
    res.status(400).send("missing or invalid 'optionSelected' parameter");
    return;
  }

  const name = req.body.name;
  if (typeof name !== "string") {
    res.status(400).send("missing or invalid 'name' parameter");
    return;
  }

  const voter = req.body.voter;
  if (typeof voter !== "string") {
    res.status(400).send("missing or invalid 'voter' parameter");
    return;
  }

  const poll: Poll | undefined = polls.get(name);
  if (poll === undefined) {
    res.status(400).send(`no poll with name '${name}'`);
    return;
  }

  const now = Date.now();
  if (now >= poll.endTime) {
    res.status(400).send(`poll for "${poll.name}" has already ended`);
    return;
  }

 
  let optionSelectedObject: Option | undefined = findOption(optionSelected, poll);
  if(optionSelectedObject === undefined){
    res.status(400).send("optionSelected doesn't exist in poll");
    return;
  }
  let oldOptionSelectedObject: Option | undefined = undefined;

  if(!votes.has(voter)){
    votes.set(voter, [{optionName: optionSelected, poll: poll}]);
  } else {

    let votingAgain: number = 0;
   
    const data = votes.get(voter);
    if(data !== undefined){
      for(const option of data){
        if(option.poll.name === poll.name){
          votingAgain = votingAgain + 1;
        }
      }
    }
  
    if(votingAgain > 0){
      let data = votes.get(voter);
      if(data !== undefined){
        for(const option of data){
          if(option.poll.name === poll.name){
            oldOptionSelectedObject = findOption(option.optionName, option.poll);
            if(oldOptionSelectedObject !== undefined){
              oldOptionSelectedObject.voteNum = oldOptionSelectedObject.voteNum - 1;
              data = removeOptionSelectedFromVoter(voter, option.poll);
            }
          }
        }
        votes.set(voter, data.concat([{optionName: optionSelected, poll: poll}]));
      }
    } else {
      if(data !== undefined){
        votes.set(voter, data.concat([{optionName: optionSelected, poll: poll}]));
      }
    }
  }
  
  let voteSum: number = 0;
  optionSelectedObject.voteNum = 0;

  for(const voterIndex of votes.keys()){
    const data = votes.get(voterIndex);
    if(data !== undefined){
      for(const option of data){
        if(option.poll.name === poll.name){
          voteSum = voteSum + 1;
          if(option.optionName === optionSelected){
            optionSelectedObject.voteNum = optionSelectedObject.voteNum + 1;
          }
        }
      }
    } 
  }

  for(const voter of votes.keys()){
    const data = votes.get(voter);
    if(data !== undefined){
      for(const option of data){
        if(option.poll.name === poll.name){
          let randomOptionSelectedObject: Option | undefined = findOption(option.optionName, option.poll);
          if(randomOptionSelectedObject !== undefined){
            randomOptionSelectedObject.stat = Math.round((randomOptionSelectedObject.voteNum / voteSum) * 100);
            
          }
        }
      }
    } 
  }

  if(oldOptionSelectedObject !== undefined){
    oldOptionSelectedObject.stat = Math.round((oldOptionSelectedObject.voteNum / voteSum) * 100);
  }

  polls.set(poll.name, poll); 
  res.send({poll: poll});  
};

/**
 * Retrieves the current state of a given poll.
 * @param req the request
 * @param req the response
 */
export const getPoll = (req: SafeRequest, res: SafeResponse): void => {
  const name: string | undefined = first(req.query.name);
  if (name === undefined) {
    res.status(400).send("missing or invalid 'name' parameter");
    return;
  }

  const poll = polls.get(name);
  if (poll === undefined) {
    res.status(400).send(`no poll with name '${name}'`);
    return;
  }

  res.send({poll: poll});  // send back the current auction state
};

// Helper to return the (first) value of the parameter if any was given.
// (This is mildly annoying because the client can also give mutiple values,
// in which case, express puts them into an array.)
const first = (param: unknown): string|undefined => {
  if (Array.isArray(param)) {
    return first(param[0]);
  } else if (typeof param === 'string') {
    return param;
  } else {
    return undefined;
  }
};

/** 
* Finds the option with the name given from a poll
*@param name string name given
*@param poll poll given
*@returns Option that has that name or undefined if not found
*/
export const findOption = (name: string, poll: Poll): Option | undefined => {
  for(const option of poll.options){
    if(option.name === name){
      return option;
    }
  }
  return undefined;
}

/**
 * Removes the given OptionSelected from the voter
 * @param optionSelectedObject OptionSelected object given
 * @param voter voter given
 * @returns a new array of OptionSelected objects after the removal
 */
export const removeOptionSelectedFromVoter = (voter: string, poll: Poll): OptionSelected[] => {
  const data: OptionSelected[] | undefined = votes.get(voter);
  const newData: OptionSelected[] = [];
  if(data !== undefined){
    for(const option of data){
      if(option.poll.name !== poll.name){
        newData.push(option);
      } 
    }
  }
  return newData;

}




